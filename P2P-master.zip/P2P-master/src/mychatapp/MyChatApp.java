
package mychatapp;

import mychatapp.gui.MainScreen;


public class MyChatApp {

    
    public static void main(String[] args) {
      
        MainScreen screen = new MainScreen();
        screen.show();
    }
    
}
