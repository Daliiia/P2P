# P2P(console application)
This project was tested on NetBeans 
to run this project:
download it and open it via net beans
get to poject sources, you will find MyChatApp.java file
right click on this file and choose run file "you can run many files at the same time but the project 
was mainly tested on two open threads"
on left side of application GUI add your source port number, in middle add "localhost" and on right side
add destination port number 
click on listen button 
after clicking on listen button on the opened threads then you can click on send button
NOTE: listen button is used to save port numbers on local host so there must be saved port numbers before clicking
on send button
the data will be generated automatically.
you can send and receive at the same time. 
